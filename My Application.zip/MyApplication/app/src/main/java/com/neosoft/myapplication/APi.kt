package com.neosoft.myapplication

import retrofit2.Call
import retrofit2.http.GET

interface APi {
    @GET("2022-10-12.json?app_id=b8170f2960a546378a5ceb06a7bb6f59")
    fun getProductList(): Call<Model>
}