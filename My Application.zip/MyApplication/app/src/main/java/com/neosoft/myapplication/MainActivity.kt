package com.neosoft.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    val ret = RetrofitClient.getRetrofitInstance().create(APi::class.java)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        ret.getProductList().enqueue(object :Callback<Model>{
            override fun onResponse(call: Call<Model>, response: Response<Model>) {
                if (response.isSuccessful){
                   val gson = Gson()
                  //  val list =rates.list


                    val rates = response.body()?.rates
                    val list :ArrayList<Double> = ArrayList()
                    list.add(rates?.AED!!)
                    list.add(rates?.AFN!!)
                    list.add(rates?.ALL!!)
                    list.add(rates?.ANG!!)
                    
                    Log.d("nananan", "onResponse: ${list}")


                }
            }

            override fun onFailure(call: Call<Model>, t: Throwable) {

            }

        })


    }
}