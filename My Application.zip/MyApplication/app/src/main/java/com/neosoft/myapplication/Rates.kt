package com.neosoft.myapplication

data class Rates(
    val AED: Double,
    val AFN: Double,
    val ALL: Double,
    val AMD: Double,
    val ANG: Double
)
