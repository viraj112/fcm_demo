package com.neosoft.myapplication

data class Model(val disclaimer:String,val rates:Rates) {
}